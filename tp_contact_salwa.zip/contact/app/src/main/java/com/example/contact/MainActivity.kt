package com.example.contact

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var listViewContacts: ListView

    private val contacts = ArrayList<Contact>()

    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        listViewContacts = findViewById(R.id.listViewContacts)

        // Contacts de départ
        contacts.add(
            Contact(
                "Ben Omrane",
                "Oumaima",
                "23248151",
                "oumaima@gmail.com"
            )
        )

        contacts.add(
            Contact(
                "Ali",
                "Ahmed",
                "22345678",
                "ahmed@gmail.com"
            )
        )

        contacts.add(
            Contact(
                "Trabelsi",
                "Sarra",
                "22567890",
                "sarra@gmail.com"
            )
        )

        afficherContacts()

        // Cliquer sur un contact
        listViewContacts.setOnItemClickListener { _, _, position, _ ->

            val contact = contacts[position]

            val intent = Intent(
                this,
                DetailActivity::class.java
            )

            intent.putExtra("position", position)
            intent.putExtra("nom", contact.nom)
            intent.putExtra("prenom", contact.prenom)
            intent.putExtra("telephone", contact.telephone)
            intent.putExtra("email", contact.email)

            startActivityForResult(intent, 100)
        }
    }

    private fun afficherContacts() {

        val noms = contacts.map {
            "${it.prenom} ${it.nom}\n${it.telephone}"
        }

        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_2,
            android.R.id.text1,
            noms
        )

        listViewContacts.adapter = adapter
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(
            requestCode,
            resultCode,
            data
        )

        if (requestCode == 100 &&
            resultCode == RESULT_OK &&
            data != null
        ) {

            val position =
                data.getIntExtra("position", -1)

            if (position != -1) {

                contacts[position].nom =
                    data.getStringExtra("nom") ?: ""

                contacts[position].prenom =
                    data.getStringExtra("prenom") ?: ""

                contacts[position].telephone =
                    data.getStringExtra("telephone") ?: ""

                contacts[position].email =
                    data.getStringExtra("email") ?: ""

                afficherContacts()
            }
        }
    }
}