package com.example.contact

import android.graphics.Bitmap

data class Contact(
    var nom: String,
    var prenom: String,
    var telephone: String,
    var email: String,
    var photo: Bitmap? = null
)