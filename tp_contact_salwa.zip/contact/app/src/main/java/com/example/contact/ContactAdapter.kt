package com.example.contact

class ContactAdapter {
}