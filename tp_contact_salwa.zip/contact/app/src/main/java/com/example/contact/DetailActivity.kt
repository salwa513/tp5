package com.example.contact

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    private lateinit var editNom: EditText
    private lateinit var editPrenom: EditText
    private lateinit var editTelephone: EditText
    private lateinit var editEmail: EditText
    private lateinit var imagePhoto: ImageView
    private lateinit var btnAppeler: Button
    private lateinit var btnEmail: Button
    private lateinit var btnGalerie: Button
    private lateinit var btnCamera: Button
    private lateinit var btnEnregistrer: Button
    private lateinit var btnAnnuler: Button

    private var position = -1

    companion object {
        private const val REQUEST_GALERIE = 1
        private const val REQUEST_CAMERA = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_detail)

        // Récupérer les composants
        editNom = findViewById(R.id.editNom)
        editPrenom = findViewById(R.id.editPrenom)
        editTelephone = findViewById(R.id.editTelephone)
        editEmail = findViewById(R.id.editEmail)

        imagePhoto = findViewById(R.id.imagePhoto)

        btnAppeler = findViewById(R.id.btnAppeler)
        btnEmail = findViewById(R.id.btnEmail)
        btnGalerie = findViewById(R.id.btnGalerie)
        btnCamera = findViewById(R.id.btnCamera)
        btnEnregistrer = findViewById(R.id.btnEnregistrer)
        btnAnnuler = findViewById(R.id.btnAnnuler)

        // Récupérer les données
        position = intent.getIntExtra(
            "position",
            -1
        )

        editNom.setText(
            intent.getStringExtra("nom")
        )

        editPrenom.setText(
            intent.getStringExtra("prenom")
        )

        editTelephone.setText(
            intent.getStringExtra("telephone")
        )

        editEmail.setText(
            intent.getStringExtra("email")
        )

        // Appeler
        btnAppeler.setOnClickListener {
            appeler()
        }

        // Email
        btnEmail.setOnClickListener {
            envoyerEmail()
        }

        // Galerie
        btnGalerie.setOnClickListener {
            ouvrirGalerie()
        }

        // Caméra
        btnCamera.setOnClickListener {
            ouvrirCamera()
        }

        // Enregistrer
        btnEnregistrer.setOnClickListener {
            enregistrer()
        }

        // Annuler
        btnAnnuler.setOnClickListener {
            finish()
        }
    }

    // =====================================================
    // APPEL
    // =====================================================

    private fun appeler() {

        val telephone =
            editTelephone.text.toString()

        if (telephone.isEmpty()) {

            Toast.makeText(
                this,
                "Numéro de téléphone vide",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val intent = Intent(
            Intent.ACTION_DIAL,
            Uri.parse("tel:$telephone")
        )

        startActivity(intent)
    }

    // =====================================================
    // EMAIL
    // =====================================================

    private fun envoyerEmail() {

        val email =
            editEmail.text.toString()

        if (email.isEmpty()) {

            Toast.makeText(
                this,
                "Adresse e-mail vide",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val intent = Intent(
            Intent.ACTION_SENDTO
        )

        intent.data =
            Uri.parse("mailto:$email")

        intent.putExtra(
            Intent.EXTRA_SUBJECT,
            "Contact"
        )

        try {
            startActivity(intent)
        } catch (e: Exception) {

            Toast.makeText(
                this,
                "Aucune application e-mail disponible",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // =====================================================
    // GALERIE
    // =====================================================

    private fun ouvrirGalerie() {

        val intent = Intent(
            Intent.ACTION_PICK
        )

        intent.type = "image/*"

        startActivityForResult(
            intent,
            REQUEST_GALERIE
        )
    }

    // =====================================================
    // CAMERA
    // =====================================================

    private fun ouvrirCamera() {

        val intent = Intent(
            MediaStore.ACTION_IMAGE_CAPTURE
        )

        try {

            startActivityForResult(
                intent,
                REQUEST_CAMERA
            )

        } catch (e: Exception) {

            Toast.makeText(
                this,
                "Caméra indisponible",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // =====================================================
    // RETOUR GALERIE / CAMERA
    // =====================================================

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(
            requestCode,
            resultCode,
            data
        )

        if (resultCode != RESULT_OK) {
            return
        }

        if (requestCode == REQUEST_GALERIE) {

            val imageUri = data?.data

            if (imageUri != null) {
                imagePhoto.setImageURI(imageUri)
            }

        } else if (requestCode == REQUEST_CAMERA) {

            val bitmap =
                data?.extras?.get("data")

            if (bitmap != null) {
                imagePhoto.setImageBitmap(
                    bitmap as android.graphics.Bitmap
                )
            }
        }
    }

    // =====================================================
    // ENREGISTRER
    // =====================================================

    private fun enregistrer() {

        val nom =
            editNom.text.toString().trim()

        val prenom =
            editPrenom.text.toString().trim()

        val telephone =
            editTelephone.text.toString().trim()

        val email =
            editEmail.text.toString().trim()

        // Vérifier les champs obligatoires
        if (nom.isEmpty() ||
            prenom.isEmpty() ||
            telephone.isEmpty()
        ) {

            Toast.makeText(
                this,
                "Veuillez remplir les champs obligatoires",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // Préparer les données à retourner
        val resultIntent = Intent()

        resultIntent.putExtra(
            "position",
            position
        )

        resultIntent.putExtra(
            "nom",
            nom
        )

        resultIntent.putExtra(
            "prenom",
            prenom
        )

        resultIntent.putExtra(
            "telephone",
            telephone
        )

        resultIntent.putExtra(
            "email",
            email
        )

        setResult(
            RESULT_OK,
            resultIntent
        )

        finish()
    }
}